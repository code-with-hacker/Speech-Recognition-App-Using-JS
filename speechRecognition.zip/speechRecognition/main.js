try {
    
    var talk = document.querySelector(".talk");
    var content = document.querySelector(".content");

    const speechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    const recognition = new speechRecognition();

    recognition.onstart = function(e){
        console.log("Voice is Activated!");
    }

    recognition.onresult = function(event){
        const current = event.resultIndex;
        const transcript = event.results[current][0].transcript;
        content.textContent = transcript;
        readOutLoud(transcript);
    }

    talk.addEventListener("click", function(){
        content.textContent = "Listening...";
        recognition.start();
    });

    function readOutLoud(message){
        const speech = new SpeechSynthesisUtterance();
        if(message.includes("hi") || message.includes("hello") || message.includes("holla")){
            var date = new Date().getHours();
            if(date >= 1 && date < 12){
                var finalText = "Good Morning";
            }else if(date >= 12 && date <= 16){
                var finalText = "Good Afternoon";
            }else if(date > 16 && date <= 24){
                var finalText = "Good Evening";
            }

            speech.text = "Hi. "+finalText+". I am Fine.";
        }else if(message.includes("how are you")){
            speech.text = "I am Fine.";
        }else{
            speech.text = "Sorry I didnt Catch that.";
        }

        speech.volume = 1;
        speech.rate = 1;
        speech.pitch = 1;

        window.speechSynthesis.speak(speech);
    }

} catch (e) {
    content.textContent = e;
}